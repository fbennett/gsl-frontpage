function insertListElementFromAtom(newsNode,entry) {
    // Get the stringy stuff from the feed entry
    var title = entry.getElementsByTagName('title')[0].textContent;
    //var date = entry.getElementsByTagName('updated')[0].textContent.slice(0,10).replace("-","/","g");
    var date = entry.getElementsByTagName('published')[0].textContent.slice(0,10).replace("-","/","g");
    var link = entry.getElementsByTagName('link')[0].getAttribute("href");
    // Create the nodes
    var dtNode = document.createElement("dt");
    var ddNode = document.createElement("dd")
    var aNode = document.createElement("a");
    // Assemble all the things
    aNode.setAttribute("href",link);
    dtNode.innerHTML = date;
    ddNode.innerHTML = title;
    aNode.appendChild(ddNode);
    // Tack onto the list
    newsNode.appendChild(dtNode);
    newsNode.appendChild(aNode);
}

function populateListFromAtom(listId,atomStub) {
    // Fetch the list node
    var newsNode = document.getElementById(listId);
    // Remove all list children
    for (var i=0,ilen=newsNode.childNodes.length;i<ilen;i++) {
	newsNode.removeChild(newsNode.childNodes[0])
    }
    // Get site address
    var hostroot = ("" + document.location).slice(0,(-1*"news.html".length));
    // Fetch the atom xml
    xhr = new XMLHttpRequest()
    xhr.open("GET", hostroot + "/" + atomStub, false);
    xhr.send(null)
    var xml = xhr.responseXML;
    // Get the entries
    var entries = xml.getElementsByTagName('entry');
    for (var i=0,ilen=entries.length;i<ilen;i++) {
	var entry = entries[i];
	console.log(entry)
	insertListElementFromAtom(newsNode,entry);
    }
}

function populateNewsAndEvents() {
    populateListFromAtom("news-list","news/news/index.atom");
    populateListFromAtom("event-list","news/event/index.atom");
}
